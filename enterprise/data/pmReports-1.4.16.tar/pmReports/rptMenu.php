<?php

global $G_TMP_MENU;

$G_TMP_MENU_ALIGN = "left";

$G_TMP_MENU->AddIdRawOption('ID_REPORT_LIST',    '', 'PM REPORTS',"/images/steps.png",'showPMReportPanel(); return false;');


?>
