<?php
global $RBAC;
global $G_TMP_MENU;
$G_TMP_MENU->AddIdRawOption("ID_PM_REPORTS", "../../plugins/pmReports/report?action=consolidated", "Reports");
