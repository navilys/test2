<?php
  global $G_TMP_MENU;
  $G_TMP_MENU->AddIdRawOption('KT_SETUP', '../knowledgeTree/setupPage.php', "DMS Setup", '../plugin/knowledgeTree/images/dmsIcon.png', '', 'admToolsContent'  );  

?>