<div  style="width:680px">
<div class="boxTop">
	<div class="a"></div>
	<div class="b"></div>
	<div class="c"></div>
</div>
<div class='boxContentNormal'>
  <div class="pagedTableDefault" style="">
    <table class="Default" cellspacing="0" cellpadding="0" width="100%">
      <tr>
        <td>
          <table width="100%" cellspacing="0" cellpadding="0" border="0">
            <tr>
              <td class="headerContent">
                <table width="100%" cellspacing="0" cellpadding="0">
                  <tr>
                    <td class="tableOption" width="50%">
                    <table width="100%" cellspacing="0" cellpadding="0" style="{PREV_STEP_VIEW}"><tr><td>
                      <img width="6" src="/images/bulletButtonLeft.gif"/>
                      <a id="form[MNU_ADD]" class="tableOption" onclick="" href="{PREV_STEP}"name="form[MNU_ADD]" href="#">Previous Step {PREV_STEP_LABEL}</a>
                    </td></tr></table>  
                    </td>
                    <td class="tableOption"  width="50%">
                    <table width="100%" cellspacing="0" cellpadding="0" style="{NEXT_STEP_VIEW}"><tr><td align="right">
                      <img width="6" src="/images/bulletButton.gif"/>
                      <a id="form[MNU_ADD]" class="tableOption" onclick="" href="{NEXT_STEP}" name="form[MNU_ADD]" href="#">Next Step {NEXT_STEP_LABEL}</a>
                     </td></tr></table>                      
                    
                  </tr>
                </table>
              </td>
            </tr>
          </table>
        </td>
      </tr>
    </table>
  </div>
	<div id='dashboard' style='position:relative;width:100%;'></div>
</div>
<div class="boxBottom">
	<div class="a"></div>
	<div class="b"></div>
	<div class="c"></div>
</div>
</div>