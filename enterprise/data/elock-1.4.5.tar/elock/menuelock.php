<?php
  global $G_TMP_MENU;
  $G_TMP_MENU->AddIdRawOption('ELOCK', '../elock/setupPage', "Digital Signature Configuration", '../plugin/elock/images/E-Lock_logo.jpg', '', 'admToolsContent' );  

?>