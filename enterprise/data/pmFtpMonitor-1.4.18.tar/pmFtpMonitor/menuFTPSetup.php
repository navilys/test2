<?php

global $G_TMP_MENU;
$G_TMP_MENU->AddIdRawOption('FTPMONITORLOGS', '../pmFtpMonitor/ftpMonitorLogsList.php', "FTP Monitor Log", '', '', 'plugins');
$G_TMP_MENU->AddIdRawOption('FTPMONITORSETTINGS', '../pmFtpMonitor/ftpMonitorSettingList.php', "FTP Monitor Settings", '', '', 'plugins');