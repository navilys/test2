<?php
G::header('Location: ../dashboard/dashletsList');
die();