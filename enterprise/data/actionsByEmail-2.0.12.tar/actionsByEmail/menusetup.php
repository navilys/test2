<?php
global $G_TMP_MENU;
$G_TMP_MENU->AddIdRawOption('PM_TABLES', '../actionsByEmail/ActionByEmail.php', 'Actions By Email Log', '');