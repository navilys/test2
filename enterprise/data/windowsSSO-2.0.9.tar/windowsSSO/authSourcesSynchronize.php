<?php
/**
 * authSourcesSynchronize.php
 *
 * ProcessMaker Open Source Edition
 * Copyright (C) 2004 - 2011 Colosa Inc.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as
 * published by the Free Software Foundation, either version 3 of the
 * License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 * For more information, contact Colosa Inc, 2566 Le Jeune Rd.,
 * Coral Gables, FL, 33134, USA, or email info@colosa.com.
 *
 **/

// Verify the user permissions for this page
global $RBAC;
switch ($RBAC->userCanAccess('PM_USERS')) {
  case - 2:
    G::SendTemporalMessage('ID_USER_HAVENT_RIGHTS_SYSTEM', 'error', 'labels');
    G::header('location: ../login/login');
    die;
  break;
  case - 1:
    G::SendTemporalMessage('ID_USER_HAVENT_RIGHTS_PAGE', 'error', 'labels');
    G::header('location: ../login/login');
    die;
  break;
  case -3:
    G::SendTemporalMessage('ID_USER_HAVENT_RIGHTS_PAGE', 'error', 'labels');
    G::header('location: ../login/login');
    die;
  break;
}

// Default value for the tab parameter
if (!isset($_REQUEST['tab'])) {
  $_REQUEST['tab'] = 'synchronizeDepartments';
}

// Values for the Javascript context
$authenticationSource = array('AUTH_SOURCE_UID' => $_REQUEST['authUid'], 'CURRENT_TAB' => ($_REQUEST['tab'] == 'synchronizeDepartments' ? 0 : 1));

// Load files and variables in the head publisher singleton
$oHeadPublisher =& headPublisher::getSingleton();
$oHeadPublisher->addExtJsScript('windowsSSO/authSourcesSynchronize', false);
$oHeadPublisher->addContent('windowsSSO/authSourcesSynchronize');
$oHeadPublisher->assign('AUTHENTICATION_SOURCE', $authenticationSource);

// Render the page
global $G_PUBLISH;
$G_PUBLISH = new Publisher();
G::RenderPage('publish', 'extJs');