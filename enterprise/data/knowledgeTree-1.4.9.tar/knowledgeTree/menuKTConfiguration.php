<?php
  global $G_TMP_MENU;  
	$G_TMP_MENU->AddIdRawOption('KT_CONFIG',    '', "DMS User Configuration","",'showDMS_UserConf(); return false;');
?>