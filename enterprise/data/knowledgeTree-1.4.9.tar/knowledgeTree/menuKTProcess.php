<?php

global $G_TMP_MENU;
$G_TMP_MENU_ALIGN = "left";

$G_TMP_MENU->AddIdRawOption('KT_CONF_DMS',    '', "DMS Configuration","/images/steps.png",'showDMS_Metadata(); return false;');

?>