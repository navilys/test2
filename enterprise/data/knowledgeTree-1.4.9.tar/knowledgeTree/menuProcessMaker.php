<?php
  global $G_TMP_MENU;
  $G_TMP_MENU->AddIdRawOption('KNOWLEDGE_TREE', 'knowledgeTree/documentList', _("KnowledgeTree") );


?>