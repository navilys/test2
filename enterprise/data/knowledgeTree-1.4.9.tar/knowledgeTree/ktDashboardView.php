<!--  <iframe src="http://sgc.colosa.net/browse.php?s=<?php echo $_SESSION['KTSESSIONID']?>&u=<?php echo $_SESSION['USR_USERNAME']?>" width="100%" height="500" frameborder="0" marginWidth="0" marginHeight="0"></iframe> -->

 <iframe src="http://sgc.colosa.net/browse.php" width="100%" height="500" frameborder="0" marginWidth="0" marginHeight="0"></iframe>