<?php

$html = '
<div>

	 <div class="boxTopBlue"><div class="a"></div><div class="b"></div><div class="c"></div></div>
	 <div class="boxContentBlue">
 
	  <table width="100%" style="margin:0px;" cellspacing="0" cellpadding="0">
	  <tr>
		  <td class="userGroupTitle">DMS Root Folder</td>
		  
	  </tr>
	</table>
	</div>
	<div class="boxBottomBlue"><div class="a"></div><div class="b"></div><div class="c"></div></div>

	';
  $html.="<div id='child_0'></div>
  </div>
  ";
  echo $html;
  ?>
  <script>

  </script>
