<?php


?>
<a href="javascript:showDMS_UserConf();">DMS User Configuration</a>

<script>
	 
showDMS_UserConf(); 

</script>