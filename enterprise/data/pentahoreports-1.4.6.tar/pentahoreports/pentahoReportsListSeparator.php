<?php 
/**
 * Old view toogle button
 * @deprecated
 */
?>
<a href=# onClick="toggleTree();">[Toogle Solution-Repository]</a>
