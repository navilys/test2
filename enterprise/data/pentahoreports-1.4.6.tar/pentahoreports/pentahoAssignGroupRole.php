<?php
/**
 * @section Filename
 * pentahoAssignGroupRole.php
 * @subsection Description
 * Assign a group to a pentaho plugin role.
 * @author Gustavo Cruz <gustavo@colosa.com>
 * @date 19/05/2010
 * @subsection Copyright
 * Copyright (C) Colosa Development Team 2010
 * <hr>
 * @package plugins.pentahoreports.scripts
 */

  require_once 'classes/model/PhRoleReport.php';
  require_once 'classes/model/PhUserRole.php';
  require_once 'classes/model/PhRole.php';
  require_once 'classes/model/PhReport.php';
  require_once PATH_CORE.'classes/model/Groupwf.php';
  require_once PATH_CORE.'classes/class.groups.php';

 /**
  * The role uid passed via the GET method
  */
  $ROL_UID = $_GET['ROL_UID'];

 /**
  * The groups object
  */
  $groups  = new Groups();

 /**
  * The users roles object
  */
  $userRole = new PhUserRole();

 /**
  * This dataset stores a list of all the groups in the database
  */
  $oDataSet  = $groups->getAllGroups();

 /**
  * The role object
  */
  $role = new PhRole();

 /**
  * The role code based on the role uid parameter
  */
  $roleCode = $role->getRolCode($ROL_UID);

  // loading the tree class and initializing other parameters
  G::LoadClass('tree');
 
 /**
  * The tree object
  */
  $tree = new Tree();
 /**
  * The tree object name attribute
  */
  $tree->name = 'Users';

 /**
  * The tree object node type attribute
  */
  $tree->nodeType = "base";

 /**
  * The tree object width
  */
  $tree->width = "350px";

 /**
  * The tree object value attribute, that stores the content of a tree.
  */
  $tree->value = '
	<div class="boxTopBlue"><div class="a"></div><div class="b"></div><div class="c"></div></div>
	<div class="boxContentBlue">
  		<table width="100%" style="margin:0px;" cellspacing="0" cellpadding="0">
  			<tr>
	  			<td class="userGroupTitle">' . G::LoadTranslation('ID_ASSIGN_THE_ROLE') . ': '.$roleCode.'</td>
  			</tr>
		</table>
	</div>
	<div class="boxBottomBlue"><div class="a"></div><div class="b"></div><div class="c"></div></div>
	<div class="userGroupLink"><a href="#" onclick="backUsers(\''.$_GET['ROL_UID'].'\');return false;">' . G::LoadTranslation('ID_BACK_TO_USERS_LIST') . '</a></div>';

 /**
  * The tree object showSign attribute set to false.
  */
  $tree->showSign = false;
  // Iterating over the groups and assembling the list
  foreach ($oDataSet as $group) {
      $ID_ASSIGN = G::LoadTranslation('ID_ASSIGN');
      $user    = '['.$group->getGrpTitle().']';
      $GRP_UID = $group->getGrpUid();
      $html = "
	      <table cellspacing='0' cellpadding='0' border='1' style='border:0px;'>
	        <tr>
	          <td width='250px' class='treeNode' style='border:0px;background-color:transparent;'>{$user}</td>
	          <td class='treeNode' style='border:0px;background-color:transparent;'>[<a href=\"javascript:assignGroupToRole('{$ROL_UID}','{$GRP_UID}');\">{$ID_ASSIGN}</a>]</td>
	        </tr>
	      </table>";
      // check if the group exists in the role and render the assign link
      if (!$userRole->existsInRole($GRP_UID,$ROL_UID)){
        $ch = &$tree->addChild('', $html, array('nodeType' => 'child'));
        $ch->point = '<img src="/images/users.png" />';
      }
  }
  // print the rendered tree.
  print ($tree->render());
