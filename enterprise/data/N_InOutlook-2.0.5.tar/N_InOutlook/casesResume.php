<html>
<head>
<title>Cases Folder</title>
</head>
<body style="background-color: #FFFFFF;" oncontextmenu="return false;">
<table cellpadding="10" style="width: 100%;height: 100%;background-color: #FFFFFF;">
<tr style="height: 93px;">
  <td style="width: 100%;font-family: Helvetica;font-size: 24pt;font-weight: bold;">Cases Folder</td><td style="width: 298px;"><img src="/plugin/N_InOutlook/processmaker.logo.jpg" alt="ProcessMaker" /></td>
</tr>
<tr height="40">
  <td>&nbsp;</td>
</tr>
<tr height="40">
  <td colspan="2" style="font-family: Helvetica;font-size: 12pt;font-weight: bold;">Description</td>
</tr>
<tr>
  <td colspan="2" valign="top" style="font-family: Helvetica;font-size: 10pt;">
  <p align="justify">
    This folder shows all user cases sorted into folders based on the status of the case.
<br /><br />
You will also notice that the Folder �B. Inbox" shows the number of new cases assigned to the current user that are pending review.
  </p>
  </td>
</tr>
</table>
</body>
</html>