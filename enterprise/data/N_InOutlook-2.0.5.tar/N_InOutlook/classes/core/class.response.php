<?php
/*
 * Class Response.
 * @author Julio Cesar Laura Avendaño <juliocesar@nightlies.com> <contact@julio-laura.com>
 * @version 1.0 (2011-04-01)
 * @link http://plugins.nightlies.com
 */

class Response extends stdclass {

  public $status = null;

}

?>