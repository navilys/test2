<?php
global $G_TMP_MENU;

$G_TMP_MENU->AddIdRawOption('PM_EXTERNAL_REGISTRATION', '../externalRegistration/admin', 'External Registration', '', '', 'plugins');